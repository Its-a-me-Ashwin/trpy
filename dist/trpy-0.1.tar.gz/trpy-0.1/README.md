### WX-250s python API

This python package is used to control robot arms which can be interacted with a U2D2 module. 
Gives an easy to use python API to control robot arms.
It allows you to record the and playback movements from the robot arm.
It incorporates the IK and FK for the robot arms. 
It allows you to use a simple GUI to splice and edit the recordings. 


## Supported Robot arms
* WX-250 (Tested)
* WX-450